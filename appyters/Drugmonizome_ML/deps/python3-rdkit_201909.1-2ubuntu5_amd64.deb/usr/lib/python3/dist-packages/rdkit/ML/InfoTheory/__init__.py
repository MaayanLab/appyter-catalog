""" Information Theory functionality

"""
from rdkit.ML.InfoTheory.rdInfoTheory import *
