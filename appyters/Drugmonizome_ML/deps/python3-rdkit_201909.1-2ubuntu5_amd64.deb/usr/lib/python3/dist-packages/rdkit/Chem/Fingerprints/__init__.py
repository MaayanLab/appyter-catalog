#
#  Copyright (C) 2003  Greg Landrum and Rational Discovery LLC
#
