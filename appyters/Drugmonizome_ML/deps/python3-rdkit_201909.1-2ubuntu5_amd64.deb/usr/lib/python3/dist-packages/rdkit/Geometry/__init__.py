""" A module for Geometry stuff	
 
"""
from rdkit import DataStructs
from rdkit.Geometry.rdGeometry import *
