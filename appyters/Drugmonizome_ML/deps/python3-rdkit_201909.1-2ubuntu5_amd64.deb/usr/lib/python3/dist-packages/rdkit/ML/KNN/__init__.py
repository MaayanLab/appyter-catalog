# copyright 2000, greg landrum
"""

Here is the implementation for K-nearest neighbors

"""
