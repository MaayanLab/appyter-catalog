# package indicator for spin Graphics
# $Id$
version_maj_number = 1.1
version_min_number = 0
version = "%s.%s" % (version_maj_number, version_min_number)
