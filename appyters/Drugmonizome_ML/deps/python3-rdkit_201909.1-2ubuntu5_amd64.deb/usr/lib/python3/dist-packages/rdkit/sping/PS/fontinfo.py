# Adobe's official Names for Acrobat's (?) fonts
StandardRomanFonts = [
  'Courier', 'Courier-Bold', 'Courier-Oblique', 'Courier-BoldOblique', 'Helvetica',
  'Helvetica-Bold', 'Helvetica-Oblique', 'Helvetica-BoldOblique', 'Times-Roman', 'Times-Bold',
  'Times-Italic', 'Times-BoldItalic'
]

NonRomanFonts = ["Symbol", "ZapfDingbats"]
