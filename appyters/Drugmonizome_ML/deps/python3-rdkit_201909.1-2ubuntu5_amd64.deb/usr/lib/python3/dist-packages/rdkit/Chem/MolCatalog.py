# $Id$
#
#  Copyright (C) 2006 Greg Landrum
#
from rdkit.Chem.rdMolCatalog import *
