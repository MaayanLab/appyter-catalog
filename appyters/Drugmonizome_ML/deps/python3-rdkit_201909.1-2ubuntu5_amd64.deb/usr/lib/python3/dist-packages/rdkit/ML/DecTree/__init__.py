# copyright 2000, greg landrum
"""

Here we're implementing the Decision Tree stuff found in Chapter 3 of
Tom Mitchell's Machine Learning Book.

"""
